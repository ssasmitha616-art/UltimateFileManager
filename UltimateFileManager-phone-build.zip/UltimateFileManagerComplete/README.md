# Ultimate File Manager

A Kotlin/Jetpack Compose Android file-manager foundation.

Implemented:
- Browse internal storage
- Folder navigation
- Search
- Hidden-file toggle
- Multi-select
- Select all
- Copy
- Move
- Paste
- Recursive folder copy
- Delete
- Rename
- Create folder
- File details
- Folder size
- Read/write information
- Recent modification display
- Material 3 UI
- GitHub Actions debug APK build

Important:
Android's storage model and Google Play policy do not allow a generic file manager to silently access everything on every device. A production release should use SAF/MediaStore and request only the permissions justified by the app's declared core functionality.

Not yet implemented as production modules:
SMB/SFTP/WebDAV, cloud APIs, encrypted vault, archive formats beyond what is added as a library, media codecs, EPUB/PDF rendering, full-text indexing, plugin sandbox, automation engine, device-to-device transfer, signed release pipeline, Play Console compliance, localization, and automated test coverage.

Those require additional dependencies, platform-specific implementations, security review, and provider credentials where applicable.
