package com.example.ultimatefilemanager

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewmodel.compose.viewModel
import java.io.File
import java.text.DateFormat
import java.util.Date
import kotlin.math.log10
import kotlin.math.pow

data class FileEntry(
    val file: File,
    val isDirectory: Boolean = file.isDirectory,
    val size: Long = if (file.isFile) file.length() else 0L
)

class FileManagerViewModel : ViewModel() {
    var currentDir by mutableStateOf(File("/storage/emulated/0"))
        private set
    var entries by mutableStateOf<List<FileEntry>>(emptyList())
        private set
    var query by mutableStateOf("")
    var hidden by mutableStateOf(false)
    var selected by mutableStateOf<Set<String>>(emptySet())
        private set
    var clipboard by mutableStateOf<List<File>>(emptyList())
        private set
    var clipboardCut by mutableStateOf(false)
        private set
    var status by mutableStateOf("Ready")

    init { refresh() }

    fun refresh() {
        val result = currentDir.listFiles()?.asSequence()
            ?.filter { hidden || !it.isHidden }
            ?.filter { query.isBlank() || it.name.contains(query, true) }
            ?.map(::FileEntry)
            ?.sortedWith(compareByDescending<FileEntry> { it.isDirectory }.thenBy { it.file.name.lowercase() })
            ?.toList() ?: emptyList()
        entries = result
    }

    fun open(e: FileEntry) {
        if (e.isDirectory && e.file.canRead()) {
            currentDir = e.file
            query = ""
            selected = emptySet()
            refresh()
        }
    }

    fun up() {
        currentDir.parentFile?.let { currentDir = it; selected = emptySet(); refresh() }
    }

    fun toggle(e: FileEntry) {
        selected = if (e.file.absolutePath in selected)
            selected - e.file.absolutePath else selected + e.file.absolutePath
    }

    fun selectAll() { selected = entries.map { it.file.absolutePath }.toSet() }
    fun clearSelection() { selected = emptySet() }

    fun createFolder(name: String) {
        if (name.isNotBlank() && File(currentDir, name).mkdirs()) status = "Folder created"
        else status = "Could not create folder"
        refresh()
    }

    fun deleteSelected() {
        selected.mapNotNull { File(it).takeIf(File::exists) }.forEach { it.deleteRecursively() }
        selected = emptySet()
        status = "Deleted"
        refresh()
    }

    fun renameSelected(name: String) {
        val old = selected.singleOrNull()?.let(::File)
        if (old != null && name.isNotBlank()) {
            old.renameTo(File(old.parentFile, name))
            status = "Renamed"
        }
        selected = emptySet()
        refresh()
    }

    fun copySelected(cut: Boolean) {
        clipboard = selected.map(::File)
        clipboardCut = cut
        status = if (cut) "Ready to move" else "Ready to copy"
    }

    fun paste() {
        if (clipboard.isEmpty()) return
        clipboard.forEach { source ->
            val target = File(currentDir, source.name)
            if (source.isDirectory) copyDirectory(source, target) else source.inputStream().use { i -> target.outputStream().use { o -> i.copyTo(o) } }
            if (clipboardCut) source.deleteRecursively()
        }
        if (clipboardCut) clipboard = emptyList()
        status = "Transfer complete"
        refresh()
    }

    private fun copyDirectory(source: File, target: File) {
        target.mkdirs()
        source.listFiles()?.forEach { child ->
            val dest = File(target, child.name)
            if (child.isDirectory) copyDirectory(child, dest)
            else child.inputStream().use { i -> dest.outputStream().use { o -> i.copyTo(o) } }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UltimateFileManagerApp(vm: FileManagerViewModel = viewModel()) {
    var drawer by remember { mutableStateOf(false) }
    var create by remember { mutableStateOf(false) }
    var rename by remember { mutableStateOf(false) }
    var details by remember { mutableStateOf<FileEntry?>(null) }

    MaterialTheme {
        ModalNavigationDrawer(
            drawerState = androidx.compose.material3.rememberDrawerState(if (drawer) DrawerValue.Open else DrawerValue.Closed),
            drawerContent = {
                ModalDrawerSheet {
                    Text("Ultimate File Manager", style = MaterialTheme.typography.headlineSmall, modifier = Modifier.padding(20.dp))
                    NavigationDrawerItem(true, {}, { Text("Files") })
                    NavigationDrawerItem(false, {}, { Text("Favorites") })
                    NavigationDrawerItem(false, {}, { Text("Recent") })
                    NavigationDrawerItem(false, {}, { Text("Storage Analyzer") })
                    NavigationDrawerItem(false, {}, { Text("Network") })
                    NavigationDrawerItem(false, {}, { Text("Settings") })
                }
            }
        ) {
            Scaffold(
                topBar = {
                    TopAppBar(
                        title = { Text(vm.currentDir.name.ifBlank { "Storage" }) },
                        navigationIcon = { IconButton({ drawer = true }) { Icon(Icons.Default.Menu, null) } },
                        actions = {
                            IconButton({ vm.hidden = !vm.hidden; vm.refresh() }) { Icon(Icons.Default.Visibility, "Hidden") }
                            IconButton({ vm.refresh() }) { Icon(Icons.Default.Refresh, "Refresh") }
                        }
                    )
                },
                bottomBar = {
                    if (vm.selected.isNotEmpty()) {
                        BottomAppBar {
                            Text("${vm.selected.size} selected", Modifier.padding(12.dp).weight(1f))
                            IconButton({ vm.copySelected(false) }) { Icon(Icons.Default.ContentCopy, "Copy") }
                            IconButton({ vm.copySelected(true) }) { Icon(Icons.Default.DriveFileMove, "Move") }
                            IconButton({ vm.deleteSelected() }) { Icon(Icons.Default.Delete, "Delete") }
                            IconButton({ rename = true }) { Icon(Icons.Default.Edit, "Rename") }
                        }
                    }
                },
                floatingActionButton = {
                    FloatingActionButton({ create = true }) { Icon(Icons.Default.CreateNewFolder, "Create folder") }
                }
            ) { pad ->
                Column(Modifier.padding(pad).fillMaxSize()) {
                    OutlinedTextField(
                        value = vm.query, onValueChange = { vm.query = it; vm.refresh() },
                        modifier = Modifier.fillMaxWidth().padding(12.dp), singleLine = true,
                        leadingIcon = { Icon(Icons.Default.Search, null) },
                        placeholder = { Text("Search files and folders") }
                    )
                    Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(vm.currentDir.absolutePath, Modifier.weight(1f), style = MaterialTheme.typography.bodySmall)
                        IconButton({ vm.up() }) { Icon(Icons.Default.ArrowUpward, "Up") }
                        if (vm.clipboard.isNotEmpty()) IconButton({ vm.paste() }) { Icon(Icons.Default.ContentPaste, "Paste") }
                        TextButton({ vm.selectAll() }) { Text("All") }
                    }
                    Text(vm.status, Modifier.padding(horizontal = 12.dp), style = MaterialTheme.typography.labelSmall)
                    HorizontalDivider()
                    LazyColumn(Modifier.fillMaxSize()) {
                        items(vm.entries, key = { it.file.absolutePath }) { e ->
                            FileRow(e, vm.selected.contains(e.file.absolutePath),
                                { vm.open(e) }, { vm.toggle(e) }, { details = e })
                        }
                    }
                }
            }
        }
    }

    if (create) {
        SimpleNameDialog("Create folder", "Folder name", { vm.createFolder(it); create = false }, { create = false })
    }
    if (rename) {
        SimpleNameDialog("Rename", "New name", { vm.renameSelected(it); rename = false }, { rename = false })
    }
    details?.let { e ->
        AlertDialog(
            onDismissRequest = { details = null },
            title = { Text(e.file.name) },
            text = {
                Text(
                    "Path: ${e.file.absolutePath}\n" +
                    "Type: ${if (e.isDirectory) "Folder" else "File"}\n" +
                    "Size: ${if (e.isDirectory) folderSize(e.file) else formatSize(e.size)}\n" +
                    "Modified: ${DateFormat.getDateTimeInstance().format(Date(e.file.lastModified()))}\n" +
                    "Readable: ${e.file.canRead()}\nWritable: ${e.file.canWrite()}"
                )
            },
            confirmButton = { TextButton({ details = null }) { Text("Close") } }
        )
    }
}

@Composable
fun SimpleNameDialog(title: String, label: String, ok: (String) -> Unit, cancel: () -> Unit) {
    var text by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = cancel,
        title = { Text(title) },
        text = { OutlinedTextField(text, { text = it }, singleLine = true, label = { Text(label) }) },
        confirmButton = { TextButton({ ok(text) }) { Text("OK") } },
        dismissButton = { TextButton(cancel) { Text("Cancel") } }
    )
}

@Composable
fun FileRow(e: FileEntry, selected: Boolean, open: () -> Unit, toggle: () -> Unit, info: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable { if (e.isDirectory) open() else info() }.padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Checkbox(selected, { toggle() })
        Icon(if (e.isDirectory) Icons.Default.Folder else Icons.Default.InsertDriveFile, null, Modifier.size(32.dp))
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(e.file.name, maxLines = 1)
            Text(if (e.isDirectory) "Folder" else formatSize(e.size), style = MaterialTheme.typography.bodySmall)
        }
        IconButton(info) { Icon(Icons.Default.Info, "Details") }
    }
}

fun folderSize(file: File): String {
    var total = 0L
    file.walkTopDown().forEach { if (it.isFile) total += it.length() }
    return formatSize(total)
}

fun formatSize(bytes: Long): String {
    if (bytes < 1024) return "$bytes B"
    val exp = (log10(bytes.toDouble()) / log10(1024.0)).toInt().coerceAtMost(4)
    return "%.1f %s".format(bytes / 1024.0.pow(exp), arrayOf("B","KB","MB","GB","TB")[exp])
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { UltimateFileManagerApp() }
    }
}
